package com.cg.laps.beans;

public class ApprovedLoans {

	int applicationId;
	String customerName;
	double amountOfLoanGranted;
	double monthlyInstallment;
	double rateOfInterest;
	double totalAmountPayable;
	
	//default Constructor
	public ApprovedLoans() {
		// TODO Auto-generated constructor stub
	}

	//Parameterized Constructor
	public ApprovedLoans(int applicationId, String customerName, double amountOfLoanGranted, double monthlyInstallment,
			double rateOfInterest, double totalAmountPayable) {
		super();
		this.applicationId = applicationId;
		this.customerName = customerName;
		this.amountOfLoanGranted = amountOfLoanGranted;
		this.monthlyInstallment = monthlyInstallment;
		this.rateOfInterest = rateOfInterest;
		this.totalAmountPayable = totalAmountPayable;
	}

	//Getters and Setters
	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}

	public void setAmountOfLoanGranted(double amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}

	public double getMonthlyInstallment() {
		return monthlyInstallment;
	}

	public void setMonthlyInstallment(double monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	public double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public double getTotalAmountPayable() {
		return totalAmountPayable;
	}

	public void setTotalAmountPayable(double totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}

	@Override
	public String toString() {
		return "ApprovedLoans [applicationId=" + applicationId + ", customerName=" + customerName
				+ ", amountOfLoanGranted=" + amountOfLoanGranted + ", monthlyInstallment=" + monthlyInstallment
				+ ", rateOfInterest=" + rateOfInterest + ", totalAmountPayable=" + totalAmountPayable + "]";
	}

	
	
	

}
