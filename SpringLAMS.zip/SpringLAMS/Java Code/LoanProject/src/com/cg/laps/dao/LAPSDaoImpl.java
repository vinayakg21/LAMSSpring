package com.cg.laps.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.laps.beans.ApprovedLoans;
import com.cg.laps.beans.CustomerDetails;
import com.cg.laps.beans.LoanApplication;
import com.cg.laps.beans.LoanProgramsOffered;
import com.cg.laps.exception.LAPSException;
import com.cg.laps.util.DBUtil;

public class LAPSDaoImpl implements LAPSDao {

	Connection con=null;
	PreparedStatement pst=null;
	Statement st=null;
	ResultSet rs=null;
	int data=0;
	Logger logger=null;
	
	long applicationId;
	
	public LAPSDaoImpl() {
		// TODO Auto-generated constructor stub
		logger=Logger.getLogger(LAPSDaoImpl.class);
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public int login(String username, String password, String role) throws LAPSException {
		// TODO Auto-generated method stub
		con=DBUtil.getConnection();
		String selectQry="select count(*) as COUNT from LAPSUsers where login_id=? and password=? and role=?";
		try {
			pst=con.prepareStatement(selectQry);
			pst.setString(1,username);
			pst.setString(2,password);
			pst.setString(3,role);
			rs=pst.executeQuery();
			rs.next();
			int count=Integer.parseInt(rs.getString("COUNT"));
			if(count==1)
				return 1;
				logger.info("Registered Successfully");
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("Problem in authenticating"+e.getMessage());
			logger.error("Problem in authenticating");
			
		}
		
		
		return 2;
	}

	@Override
	public ArrayList<LoanProgramsOffered> viewLoanProgramOffered() throws LAPSException {
		
		ArrayList<LoanProgramsOffered> loanList=null;
		try
		{
			loanList=new ArrayList<LoanProgramsOffered>();
			con=DBUtil.getConnection();
			String selectQry="select * from LAPSLoanProgramsOffered";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			
			while(rs.next())
			{
				loanList.add(new LoanProgramsOffered(rs.getString("ProgramName"),rs.getString("description"),rs.getString("type"),rs.getInt("durationinyears"),rs.getDouble("minloanamount"),rs.getDouble("maxloanamount"),rs.getDouble("rateofinterest"),rs.getString("proofs_required")));
			}
		}
		catch(Exception e)
		{
			System.out.println("Problem in the fetching data"+e.getMessage());
			logger.error("Problem in the fetching data");
		}
		return loanList;
		
	}

	@Override
	public int addLoanProgram(LoanProgramsOffered loanPrograms) throws LAPSException {
		// TODO Auto-generated method stub
		String insertQry="insert into LAPSLoanProgramsOffered values (?,?,?,?,?,?,?,?)";
		try {
			con=DBUtil.getConnection();
			pst=con.prepareStatement(insertQry);
			pst.setString(1, loanPrograms.getProgramName());
			pst.setString(2, loanPrograms.getDescription());
			pst.setString(3, loanPrograms.getType());
			pst.setInt(4, loanPrograms.getDurationInYears());
			pst.setDouble(5, loanPrograms.getMinLoanAmount());
			pst.setDouble(6, loanPrograms.getMaxLoanAmount());
			pst.setDouble(7, loanPrograms.getRateOfInterest());
			pst.setString(8, loanPrograms.getProofsRequired());
			data = pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			System.out.println("Problem in inserting the Loan Programs"+e.getMessage());
			logger.error("Problem in inserting the Loan Programs");
		}
		logger.info("Data inserted successfully in the loan programs");
		return data;
	}

	@Override
	public int deleteLoanProgram(String programName) throws LAPSException {
		// TODO Auto-generated method stub
		int returnval=0;
		try 
		{			
			con=DBUtil.getConnection();
			String selectQry="delete from LAPSLoanProgramsOffered where ProgramName=?";
			pst=con.prepareStatement(selectQry);
			pst.setString(1,programName);
			returnval=pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			System.out.println("Problem in the deleting Loan Program"+e.getMessage());
			logger.error("Problem in the deleting Loan Program");
		}
		logger.info("Data deleted successfully from loan programs offered");
		return returnval;
	}

	@Override
	public int updateLoanProgram(LoanProgramsOffered loanPrograms) throws LAPSException {
		// TODO Auto-generated method stub
		int returnval=0;
		try 
		{			
			con=DBUtil.getConnection();
			String selectQry="update LAPSLoanProgramsOffered set description=?,type=?,durationinyears=?,minloanamount=?,maxloanamount=?,rateofinterest=?,proofs_required=? where ProgramName=?";
			pst=con.prepareStatement(selectQry);
			pst.setString(1,loanPrograms.getDescription());
			pst.setString(2,loanPrograms.getType());
			pst.setInt(3,loanPrograms.getDurationInYears());
			pst.setDouble(4,loanPrograms.getMinLoanAmount());
			pst.setDouble(5,loanPrograms.getMaxLoanAmount());
			pst.setDouble(6,loanPrograms.getRateOfInterest());
			pst.setString(7,loanPrograms.getProofsRequired());
			pst.setString(8,loanPrograms.getProgramName());
			
			returnval=pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			System.out.println("Problem in updating the loan program"+e.getMessage());
			logger.error("Problem in updating the loan program");
		}
		return returnval;
	}

	@Override
	public ArrayList<LoanApplication> viewAcceptedLoans() throws LAPSException {
		// TODO Auto-generated method stub
		ArrayList<LoanApplication> Llist=new ArrayList<LoanApplication>();
		try {
			con=DBUtil.getConnection();
			String selectQry="select * from LAPSLoanApplication where Status='accepted'";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				Llist.add(new LoanApplication(rs.getInt("Application_Id"),
						(rs.getDate("application_date")).toLocalDate(),rs.getString("Loan_program"),rs.getInt("AmountofLoan")
						,rs.getString("AddressofProperty"),rs.getInt("AnnualFamilyIncome")
						,rs.getString("DocumentProofsAvailable"),rs.getString("GuaranteeCover")
						,rs.getInt("MarketValueofGuaranteeCover"),rs.getString("Status"),(rs.getDate("DateOfInterview")).toLocalDate()));
			}
		} catch (Exception e) {
			System.out.println("Problem in fetching data of the Accepted Loan"+e.getMessage());
			logger.error("Problem in fetching data of the Accepted Loan");
		}
		return Llist;
	}

	@Override
	public ArrayList<LoanApplication> viewRejectedLoans() throws LAPSException {
		// TODO Auto-generated method stub
		ArrayList<LoanApplication> Llist=new ArrayList<LoanApplication>();
		try {
			con=DBUtil.getConnection();
			String selectQry="select * from LAPSLoanApplication where Status='rejected'";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				Llist.add(new LoanApplication(rs.getInt("Application_Id"),
						(rs.getDate("application_date")).toLocalDate(),rs.getString("Loan_program"),rs.getInt("AmountofLoan")
						,rs.getString("AddressofProperty"),rs.getInt("AnnualFamilyIncome")
						,rs.getString("DocumentProofsAvailable"),rs.getString("GuaranteeCover")
						,rs.getInt("MarketValueofGuaranteeCover"),rs.getString("Status"),(rs.getDate("DateOfInterview")).toLocalDate()));
			}
		} catch (Exception e) {
			System.out.println("Problem in fetching Rejected Applications"+e.getMessage());
			logger.error("Problem in fetching Rejected Applications");
		}
		return Llist;
	}

	@Override
	public ArrayList<ApprovedLoans> viewApprovedLoans() throws LAPSException {
		// TODO Auto-generated method stub
		ArrayList<ApprovedLoans> Llist=new ArrayList<ApprovedLoans>();
		try {
			con=DBUtil.getConnection();
			String selectQry="select * from LAPSApprovedLoans";
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
				Llist.add(new ApprovedLoans(rs.getInt("Application_Id"),
						rs.getString("Customer_name"),rs.getInt("amountofloangranted")
						,rs.getInt("monthlyinstallment"),rs.getInt("rateofinterest"),
						rs.getInt("totalamountpayable")));
			}
		} catch (Exception e) {
			System.out.println("Problem in fetching Approved Loans"+e.getMessage());
			logger.error("Problem in fetching Approved Loans");
			
		}

		return Llist;
		
	}
	
	private long generatepplicationId() throws LAPSException{
		con = DBUtil.getConnection();
		String sql = "SELECT seq_application_id.NEXTVAL FROM DUAL";
		
		try {
			Statement st = con.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			applicationId=rst.getLong(1);
			return rst.getLong(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Problem in generation course id "+e.getMessage());
			logger.error("Problem in generation course id ");
		}
		return 1;
	}

	@Override
	public int addLoanApplication(LoanApplication loanApp) throws LAPSException {
		// TODO Auto-generated method stub
		try 
		{
			generatepplicationId();
			System.out.println("Application ID"+applicationId);
			LocalDate idate = LocalDate.now().plus(10, ChronoUnit.DAYS);
			String status="applied";
			con=DBUtil.getConnection();
			String insertQry2="insert into LAPSLoanApplication values(?,?,?,?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQry2);
			pst.setLong(1, applicationId);
			pst.setDate(2, Date.valueOf(LocalDate.now()));
			pst.setString(3, loanApp.getLoanProgram());
			pst.setDouble(4, loanApp.getAmountOfLoan());
			pst.setString(5, loanApp.getAddressOfProperty());
			pst.setDouble(6, loanApp.getAnnualFamilyIncome());
			pst.setString(7, loanApp.getDocumentProofsAvailable());
			pst.setString(8, loanApp.getGuaranteeCover());
			pst.setDouble(9, loanApp.getMarketValueofGuaranteeCover());
			pst.setString(10, status);
			pst.setDate(11, Date.valueOf(idate));
			
			data = pst.executeUpdate();
			con.commit();
			
		}
		catch(Exception e)
		{
			System.out.println("Problem in the inserting data in the Loan Application"+e.getMessage());
			logger.error("Problem in the inserting data in the Loan Application");
		}
		logger.info("Loan Application added successfully");
		return data;
	}

	
	@Override
	public int addCustomerDetails(CustomerDetails custDetails) throws LAPSException {
		// TODO Auto-generated method stub
		try 
		{
			
			String insertQry1="insert into LAPSCustomerDetails values (?,?,?,?,?,?,?,?)";
			pst=con.prepareStatement(insertQry1);
			pst.setLong(1, applicationId);
			pst.setString(2, custDetails.getApplicantName());
			pst.setDate(3, Date.valueOf(custDetails.getDateOfBirth()));
			pst.setString(4, custDetails.getMaritalStatus());
			pst.setLong(5, custDetails.getPhoneNumber());
			pst.setLong(6, custDetails.getMobileNumber());
			pst.setInt(7,custDetails.getCountOfDependents());
			pst.setString(8, custDetails.getEmailId());
			data = pst.executeUpdate();
			
		}
		catch(Exception e)
		{
			System.out.println("Problem in the inserting in the Customer Details"+e.getMessage());
			logger.error("Problem in the inserting in the Customer Details");
		}
		logger.info("Customer details added successfully");
		return data;
	}
	
	
	@Override
	public LoanApplication viewApplicationStatusById(int id) throws LAPSException {
		// TODO Auto-generated method stub
		LoanApplication obj=null;
		try {
			con=DBUtil.getConnection();
			String selectQry="select * from LAPSLoanApplication where Application_Id=?";
			pst=con.prepareStatement(selectQry);
			pst.setInt(1,id);
			rs = pst.executeQuery();
			while(rs.next())
			{
				obj=new LoanApplication(rs.getInt("Application_Id"),
						(rs.getDate("application_date")).toLocalDate(),rs.getString("Loan_program"),rs.getInt("AmountofLoan")
						,rs.getString("AddressofProperty"),rs.getInt("AnnualFamilyIncome")
						,rs.getString("DocumentProofsAvailable"),rs.getString("GuaranteeCover")
						,rs.getInt("MarketValueofGuaranteeCover"),rs.getString("Status"),(rs.getDate("DateOfInterview")).toLocalDate());
			}
		} catch (Exception e) 
		{
			System.out.println("Error in the fetching data"+e.getMessage());
			logger.error("Error in the fetching data");
		}		
		return obj;
	}

	@Override
	public ArrayList<LoanApplication> viewApplicationByLoanProgram(String programName) throws LAPSException {
			ArrayList<LoanApplication> Llist=new ArrayList<LoanApplication>();
		
			try {
				con=DBUtil.getConnection();
				String selectQry="select * from LAPSLoanApplication where Loan_program=?";
				pst=con.prepareStatement(selectQry);
				pst.setString(1,programName);
				rs = pst.executeQuery();
				while(rs.next())
				{
						Llist.add(new LoanApplication(rs.getInt("Application_Id"),
								(rs.getDate("application_date")).toLocalDate(),rs.getString("Loan_program"),rs.getInt("AmountofLoan")
								,rs.getString("AddressofProperty"),rs.getInt("AnnualFamilyIncome")
								,rs.getString("DocumentProofsAvailable"),rs.getString("GuaranteeCover")
								,rs.getInt("MarketValueofGuaranteeCover"),rs.getString("Status"),(rs.getDate("DateOfInterview")).toLocalDate()));
				}
			} catch (Exception e) {
				System.out.println("problem in fetching application by loan program"+e.getMessage());
				logger.info("problem in fetching application by loan program");
			}
			return Llist;
	}

	@Override
	public int updateApplicationStatus(int appId, String newStatus, LocalDate date) throws LAPSException {
		// TODO Auto-generated method stub
		try
		{
			con=DBUtil.getConnection();
			String updateQry="update LAPSLoanApplication set status = ?, DateOfInterview = ? where Application_Id = ?";
			pst=con.prepareStatement(updateQry);
			pst.setString(1, newStatus);
			pst.setDate(2, Date.valueOf(date));
			pst.setInt(3, appId);
			data = pst.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println("Can't Update Application status");
			logger.info("Can't Update Application status");
		}
		return data;
	}

	@Override
	public int setStatusAfterInterview(int appId, String newStatus) throws LAPSException {
		// TODO Auto-generated method stub
		try
		{
			con=DBUtil.getConnection();
			String updateQry="update LAPSLoanApplication set status = ? where Application_Id = ?";
			pst=con.prepareStatement(updateQry);
			pst.setString(1, newStatus);
			pst.setInt(2, appId);
			data = pst.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println("Can't update status"+e.getMessage());
			logger.info("Can't update status");
		}
		return data;
	}

	@Override
	public int addToApprovedLoan(ApprovedLoans ap) throws LAPSException {
		// TODO Auto-generated method stub
		String insertQry="insert into LAPSApprovedLoans values (?,?,?,?,?,?)";
		try 
		{
			con=DBUtil.getConnection();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, ap.getApplicationId());
			pst.setString(2, ap.getCustomerName());
			pst.setDouble(3, ap.getAmountOfLoanGranted());
			pst.setDouble(4, ap.getMonthlyInstallment());
			pst.setDouble(5, ap.getRateOfInterest());
			pst.setDouble(6, ap.getTotalAmountPayable());
			data = pst.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println("Can't insert into the approved loans"+e.getMessage());
			logger.error("Can't insert into the approved loans");
		}
		logger.info("Approved loans added successfully");
		return data;
	}

	@Override
	public LoanProgramsOffered getLoanProgramByName(String loanName) throws LAPSException {
		// TODO Auto-generated method stub
		LoanProgramsOffered obj = null;
		try
		{
			con=DBUtil.getConnection();
			System.out.println(loanName);
			String selectQry="select * from LAPSLoanProgramsOffered where ProgramName=?";
			pst=con.prepareStatement(selectQry);
			pst.setString(1,loanName);
			rs = pst.executeQuery();
			while(rs.next())
			{
				obj=new LoanProgramsOffered(rs.getString("PROGRAMNAME"), rs.getString("DESCRIPTION"), rs.getString("TYPE"), rs.getInt("DURATIONINYEARS"),rs.getDouble("MINLOANAMOUNT"), rs.getDouble("MAXLOANAMOUNT"), rs.getDouble("RATEOFINTEREST"), rs.getString("PROOFS_REQUIRED"));
			}
		} catch (Exception e) 
		{
			System.out.println("Can't fetch loan program"+e.getMessage());
			logger.error("Can't fetch loan program");
		}
		return obj;	
	}

	@Override
	public String getCustomerDetailsByAppId(int id) throws LAPSException {
		// TODO Auto-generated method stub
		CustomerDetails cd = null;
		String s=null;
		try
		{
			
			con=DBUtil.getConnection();
			String updateQry="select * from LAPSCustomerDetails where Application_Id=?";
			pst=con.prepareStatement(updateQry);
			pst.setInt(1, id);
			rs = pst.executeQuery();
			rs.next();
			s= rs.getString("APPLICANT_NAME");
			//cd = (CustomerDetails)rs.getObject(1);
		}
		catch(Exception e)
		{
			System.out.println("Can't fetch customer details"+e.getMessage());
			logger.error("Can't fetch customer details");
		}
		return s;
	}

	

}
