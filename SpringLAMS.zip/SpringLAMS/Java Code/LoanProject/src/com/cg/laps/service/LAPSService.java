package com.cg.laps.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.laps.beans.ApprovedLoans;
import com.cg.laps.beans.CustomerDetails;
import com.cg.laps.beans.LoanApplication;
import com.cg.laps.beans.LoanProgramsOffered;
import com.cg.laps.exception.LAPSException;


public interface LAPSService {

	//These are the methods accessible to the admin and lad
	public int login(String username, String password, String role) throws LAPSException;
	
	//These are the methods accessible to the admin
	public int addLoanProgram(LoanProgramsOffered loanPrograms) throws LAPSException;
	public int deleteLoanProgram(String programName) throws LAPSException; 
	public int updateLoanProgram(LoanProgramsOffered loanPrograms) throws LAPSException;
	public ArrayList<LoanApplication> viewAcceptedLoans() throws LAPSException;
	public ArrayList<LoanApplication> viewRejectedLoans() throws LAPSException;
	public ArrayList<ApprovedLoans> viewApprovedLoans() throws LAPSException;
	
	//These methods are for the customer
	public int addCustomerDetails(CustomerDetails custDetails) throws LAPSException;
	public int addLoanApplication(LoanApplication loanApp) throws LAPSException;
	public LoanApplication viewApplicationStatusById(int id) throws LAPSException;
		
	//These are the methods accessible to the lad
	public ArrayList<LoanApplication> viewApplicationByLoanProgram(String programName) throws LAPSException;
	public int updateApplicationStatus(int appId, String newStatus, LocalDate date) throws LAPSException;//change satus, add date
	public int setStatusAfterInterview(int appId, String newStatus) throws LAPSException;
	public int addToApprovedLoan(ApprovedLoans ap) throws LAPSException;
	
	//methods for everyone
	public ArrayList<LoanProgramsOffered> viewLoanProgramOffered() throws LAPSException;
	
	//utilitymethod
	public LoanProgramsOffered getLoanProgramByName(String loanName) throws LAPSException;
	public String getCustomerDetailsByAppId(int id) throws LAPSException;
	
	//Validation methods
	public boolean validateCustName(String ename) throws LAPSException;
	public boolean validatePhoneNo(long pno) throws LAPSException;
	public boolean validateMobileNo(long mno)throws LAPSException;
	public boolean validateEmailId(String mailid) throws LAPSException;
	public boolean validateLoanProgramName(String ename) throws LAPSException;
	public boolean validateLoanAmount(double min, double max, double amount)throws LAPSException;
	public boolean validateDocument(String docProof, String document)throws LAPSException;
}
