package com.cg.dto;

public @interface Column {

}
